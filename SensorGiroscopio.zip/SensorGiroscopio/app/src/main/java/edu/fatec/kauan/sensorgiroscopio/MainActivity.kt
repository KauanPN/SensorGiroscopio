package edu.fatec.kauan.sensorgiroscopio

/*
    Os imports aplicados abaixo consistam em trazer para este projeto
   classes que podemos utilizar, usar suas funções, como a Sensor que
   tem funções para definir um sensor; A classe SensorEvent tem as funçoes
   para tratar tudo que acontece com o sensor escolhido: a ckasse SensorEventListener
   tem funções parar reconhecer qualquer evento ocorrido no sensor;
   A SensorManager para gerenciar o sensor...
 */
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.widget.TextView

class MainActivity : AppCompatActivity(), SensorEventListener {
//a variável de instância sensorManager é do tipo SensorManager
    //mas será instância posteriormente (late)
    private lateinit var sensorManager: SensorManager
    // A variável de instÂncia gyroscope é do tipo Sensor e PODE ser
    // iniciada com null
    private var gyroscope: Sensor? = null
    // a variável de instância txtGyro será instanciada depois,
    // quando for definida como REFERÊNCIA do componente TextView que está na
    // tela do aplicativo
    private lateinit var txtGyro: TextView

    // A função (fun) onCreate, funcione como construtora, é sobrescrita
    // (override) da função onCreate definida na superclasse
    // AppCompatActivity, sempre quando uma função for abstrata ela deve ser
    // sobrescrita na subclasse, isso vale também para funções de classe de interface
    // (não interface grafíca)
    override fun onCreate(savedInstanceState: Bundle?) {
    // super.onCreate() invoca a função onCreate de superclasse
        super.onCreate(savedInstanceState)
        // a função setContentView faz o reconhecimento da tela, activity_main
        // que está na pasta layout, que está dentro da pasta res (R)
        setContentView(R.layout.activity_main)
    // a variável txtGyro está se tornado referência do componente txtGiro
        // a partir de seu id, que está na tela (activity_main) que está em R
        txtGyro = findViewById(R.id.txtGiro)
        // A variável gyroscope está sendo definido com o tipo de sensor
        // giroscopio, graças a instância sensorManager, podemos ter vários
        // instâncias diferentes de sensores diferentes utilizando apenas
        // uma instância de SensorManager
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        gyroscope = sensorManager.getDefaultSensor(
            Sensor.TYPE_GYROSCOPE)

        // a função onResume também é definida na superclasse e ela é
        // acionada em execução para definir o funcionamento do sensor
        override fun onResume() {
            //Invocando o onResume da superclasse
            super.onResume()
            // neste exemplo a instância sensorManager se prepara
            // para "ouvir" (listener) qualquer evento disparado pelo
            // sensor giroscópio, tendo o tempo de espera (delay) normal
         sensorManager.registerListener(this,
             gyroscope, SensorManager.SENSOR_DELAY_NORMAL)
         // NÃO digite "listner = "
            }
        }
    // onPause é função da superclasse para não realizar a leitura
    // listener, quando o smartphone estiver hibernando
        override fun onPause() {
        // invoca onPause da superclasse
            super.onPause()
        // Invoca a função unregisterListener para não realizar leituras
        // quando estiver parado/hibernando
            sensorManager.unregisterListener(this)
        }
// A função onSensorChanged é invocada quando ocorre algum evento
    // vindo de algum sensor (event: SensorEvent?)
        override fun onSensorChanged(event: SensorEvent?) {
    // o if verifica se o evento disparado é do sensor giroscópio,
    // pois outros sensores podem disparar evento, e só iremos
    // implementar o do giroscopio
            if(event?.sensor?.type == Sensor.TYPE_GYROSCOPE) {
                //As variáveis x, y e z recebem os valores vindo do
                //sensor, através da leitura do event, sendo que estás
                // valores ficam em um vetor (array) de 3 posições 0, 1 e 2
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                // a variável txtGyro, por ser do tipo TextView e uma
                // referência do componente TextView txtGiro da tela, tem
                // sua propriedade text preenchida com X: valor da variável x;
                // pula linha (\n) Y: valor da variável y e o mesmo para o z
                txtGyro.text = "X: $x \n y: $y \n z: $z"
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}// fim